//
//  youtube-ios-player-helper.h
//  youtube-ios-player-helper
//
//  Created by Niels van Hoorn on 02/09/15.
//  Copyright © 2015 YouTube Developer Relations. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for youtube-ios-player-helper.
FOUNDATION_EXPORT double youtube_ios_player_helperVersionNumber;

//! Project version string for youtube-ios-player-helper.
FOUNDATION_EXPORT const unsigned char youtube_ios_player_helperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <youtube_ios_player_helper/PublicHeader.h>

#import "YTPlayerView.h"