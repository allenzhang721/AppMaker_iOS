//
//  BookEntity.h
//  HLIOSPublisher
//
//  Created by 星宇陈 on 14/7/7.
//  Copyright (c) 2014年 Emiaostein. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BookEntity : NSObject

@end
