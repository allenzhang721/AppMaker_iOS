//
//  main.m
//  HLIOSPublisher
//
//  Created by 星宇陈 on 14/7/7.
//  Copyright (c) 2014年 Emiaostein. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
